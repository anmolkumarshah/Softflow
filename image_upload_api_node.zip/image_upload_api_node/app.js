const express = require("express");
var bodyParser = require("body-parser");
const upload = require("express-fileupload");
const fileSystem = require("fs");
const path = require("path");

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(upload());

app.post("/getfile", (req, res, next) => {
  const name = req.body.name;
  var filePath = path.join(__dirname, "uploads", name);
  res.send({ path: filePath });
});

app.post("/upload", (req, res, next) => {
  const file = req.files.file;
  const name = req.body.name;
  file.name = name;
  file.mv("./uploads/" + name, (err) => {
    if (err) {
      res.send("Error Occured while uploading file " + err);
    } else {
      res.send({
        status: "File Uploaded Successfully",
        data: __dirname + "\\uploads\\" + name,
        name: name,
      });
    }
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Listening to port ${PORT}`);
});
